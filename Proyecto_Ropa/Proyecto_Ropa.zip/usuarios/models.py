from django.db import models
from django.contrib.auth.models import User  # Utilizamos el modelo User de Django para gestionar usuarios.
from django.core.files.base import ContentFile


# Tipo de Prenda (solo 5 tipos predefinidos)
class TipoPrenda(models.Model):
    CAMISETA = 'Camiseta'
    CHAQUETA = 'Chaqueta'
    PANTALON = 'Pantalón'
    SUDADERA = 'Sudadera'
    VESTIDO = 'Vestido'

    TIPO_PRENDA_CHOICES = [
        (CAMISETA, 'Camiseta'),
        (CHAQUETA, 'Chaqueta'),
        (PANTALON, 'Pantalón'),
        (SUDADERA, 'Sudadera'),
        (VESTIDO, 'Vestido'),
    ]

    nombre = models.CharField(max_length=50, choices=TIPO_PRENDA_CHOICES, unique=True)

    def __str__(self):
        return self.nombre

class Disenador(models.Model):
    imagen = models.ImageField(upload_to='disenos/')  # Almacena la imagen
    tipo_prenda = models.CharField(max_length=100)  # Almacena el tipo de prenda
    usuario = models.ForeignKey(User, on_delete=models.CASCADE)  # Relacionado con el usuario

class Cuenta(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    apellido = models.CharField(max_length=255, default="Desconcido")
    correo = models.EmailField(unique=True)
    contrasena = models.CharField(max_length=128, default="contraseña_default")  # Define un valor predeterminado
