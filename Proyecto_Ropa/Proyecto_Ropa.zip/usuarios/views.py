# usuarios/views.py
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .serializers import SignupSerializer, LoginSerializer, DisenadorSerializer
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.authtoken.models import Token
from .models import Disenador, TipoPrenda, Cuenta
from django.contrib.auth.models import User
from django.core.files.base import ContentFile
from django.shortcuts import get_object_or_404
import base64


class RegisterUser(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = SignupSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            return Response({
                'message': 'Usuario registrado exitosamente',
                'user': {
                    'id': user.id,
                    'email': user.email,
                    'first_name': user.first_name,
                    'last_name': user.last_name,
                }
            }, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class LoginUser(APIView):
    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.validated_data['user']
            token, created = Token.objects.get_or_create(user=user)
            return Response({
                'token': token.key,
                'user': {
                    'id': user.id,
                    'email': user.email,
                    'first_name': user.first_name,
                    'last_name': user.last_name
                }
            }, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class SaveDesignView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        user = request.user  # Obtener el usuario autenticado
        
        tipo_prenda = request.data.get("tipo_prenda")
        imagen_base64 = request.data.get("imagen")

        try:
            tipo_prenda_obj = TipoPrenda.objects.get(nombre=tipo_prenda)
        except TipoPrenda.DoesNotExist:
            return Response({"error": "Tipo de prenda no válido"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            format, imgstr = imagen_base64.split(';base64,')
            ext = format.split('/')[-1]
            imagen = ContentFile(base64.b64decode(imgstr), name=f'diseno_{user.id}.{ext}')
        except Exception as e:
            return Response({"error": f"Error al procesar la imagen: {str(e)}"}, status=status.HTTP_400_BAD_REQUEST)

        Disenador.objects.create(usuario=user, tipo_prenda=tipo_prenda_obj, imagen=imagen)

        return Response({"message": "Diseño guardado exitosamente"}, status=status.HTTP_201_CREATED)
    def post(self, request):
        user = request.user
        if not user.is_authenticated:
            return Response({"error": "Usuario no autenticado"}, status=status.HTTP_401_UNAUTHORIZED)

        tipo_prenda_nombre = request.data.get("tipo_prenda")
        try:
            tipo_prenda = TipoPrenda.objects.get(nombre=tipo_prenda_nombre)
        except TipoPrenda.DoesNotExist:
            return Response({"error": "Tipo de prenda no válido"}, status=status.HTTP_400_BAD_REQUEST)

        imagen_base64 = request.data.get("imagen")
        if not imagen_base64:
            return Response({"error": "La imagen es requerida"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            format, imgstr = imagen_base64.split(';base64,')
            ext = format.split('/')[-1]
            imagen = ContentFile(base64.b64decode(imgstr), name=f'diseno_{user.id}.{ext}')
        except Exception as e:
            return Response({"error": f"Error al procesar la imagen: {str(e)}"}, status=status.HTTP_400_BAD_REQUEST)

        disenador = Disenador.objects.create(
            usuario=user,
            tipo_prenda=tipo_prenda,
            imagen=imagen
        )

        return Response({
            "message": "Diseño creado exitosamente",
            "disenador": {
                "id": disenador.id,
                "imagen": disenador.imagen.url,
                "tipo_prenda": disenador.tipo_prenda.nombre,
                "usuario": disenador.usuario.username
            }
        }, status=status.HTTP_201_CREATED)
    
class DesignListView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        # List all designs for the authenticated user
        designs = Disenador.objects.filter(usuario=request.user)
        serializer = DisenadorSerializer(designs, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

class DesignCreateView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        data = request.data.copy()
        data['usuario'] = request.user.id  # Asocia el diseño al usuario autenticado
        serializer = DisenadorSerializer(data=data)
        print(f"Token recibido: {request.headers.get('Authorization')}")

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class DesignDeleteView(APIView):
    permission_classes = [IsAuthenticated]

    def delete(self, request, pk):
        # Delete a specific design by its ID
        design = get_object_or_404(Disenador, id=pk, usuario=request.user)
        design.delete()
        return Response({'detail': 'Design deleted successfully'}, status=status.HTTP_204_NO_CONTENT)
