"use client";

import React from "react";
import { useRouter } from "next/navigation";
import { Label } from "../ui/label";
import { Input } from "../ui/input";
import { cn } from "@/lib/utils";
import { Button, Link } from "@nextui-org/react";
import { useForm, SubmitHandler } from "react-hook-form";
import { useAuth } from "@/context/auth_context";

interface LoginFormInputs {
  username: string; // Cambia a "username" porque SimpleJWT espera este campo
  password: string;
}

export default function LogInFormDemo() {
  const router = useRouter();
  const { login } = useAuth(); // Usar el contexto de autenticación
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<LoginFormInputs>();

  const onSubmit: SubmitHandler<LoginFormInputs> = async (data) => {
    try {
      console.log("Datos enviados:", data);

      // Enviar datos al endpoint JWT de Django
      const response = await fetch("http://localhost:8000/api/token/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          username: data.username, // Django espera "username" en lugar de "email"
          password: data.password,
        }),
      });

      const result = await response.json();

      if (response.ok) {
        // Si la respuesta es exitosa, guardar tokens en el contexto o almacenamiento local
        const { access, refresh } = result;
        if (access && refresh) {
          // Guardar el token de acceso y el token de refresco en localStorage
          localStorage.setItem("access_token", access);
          localStorage.setItem("refresh_token", refresh);

          // Llamar a la función de login del contexto para actualizar el estado del usuario
          login(access, data.username);

          // Mensaje de éxito y redirección
          alert("Inicio de sesión exitoso");
          router.push(`/users/${data.username}`);
        } else {
          throw new Error("El servidor no devolvió tokens válidos.");
        }
      } else {
        // Si hay un error, muestra un mensaje de error
        alert(`Error al iniciar sesión: ${result.detail || "Error desconocido"}`);
      }
    } catch (error) {
      console.error("Error al iniciar sesión:", error);
      alert("Problema con el servidor o credenciales incorrectas.");
    }
  };

  return (
    <div className="max-w-md w-full mx-auto rounded-none md:rounded-2xl p-4 md:p-8 shadow-input bg-white dark:bg-black">
      <h2 className="font-bold text-xl text-neutral-800 dark:text-neutral-200">
        Bienvenido a Fashion Station
      </h2>
      <p className="text-neutral-600 text-sm max-w-sm mt-2 dark:text-neutral-300">
        Inicia sesión en Fashion Station
      </p>

      <form className="my-8" onSubmit={handleSubmit(onSubmit)}>
        <LabelInputContainer className="mb-4">
          <Label htmlFor="username">Usuario</Label>
          <Input
            id="username"
            placeholder="Nombre de usuario"
            type="text"
            {...register("username", { required: "El usuario es requerido" })}
          />
          {errors.username && (
            <p role="alert" className="text-sm text-red-500">
              {errors.username.message}
            </p>
          )}
        </LabelInputContainer>
        <LabelInputContainer className="mb-4">
          <Label htmlFor="password">Contraseña</Label>
          <Input
            id="password"
            placeholder="••••••••"
            type="password"
            {...register("password", {
              required: "La contraseña es requerida",
            })}
          />
          {errors.password && (
            <p role="alert" className="text-sm text-red-500">
              {errors.password.message}
            </p>
          )}
        </LabelInputContainer>
        <Button
          color="secondary"
          className="w-full"
          variant="shadow"
          type="submit"
        >
          Log in &rarr;
        </Button>
        <br />
        <br />
        ¿Aún no tienes una cuenta?&nbsp;
        <Link href="/signup" color="secondary">
          Sign up
        </Link>
      </form>
    </div>
  );
}

const LabelInputContainer = ({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) => (
  <div className={cn("flex flex-col space-y-2 w-full", className)}>
    {children}
  </div>
);
