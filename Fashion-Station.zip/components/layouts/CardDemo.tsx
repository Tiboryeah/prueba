"use client";

import React, { useEffect, useState } from "react";
import { Card, CardBody, CardFooter, Image, Button } from "@nextui-org/react";

interface Design {
  id: number;
  imagen: string; // Ruta relativa como 'disenos/diseno_19.png'
  tipo_prenda: string;
}

export default function CardDemo({
  onSelectionChange,
}: {
  onSelectionChange: (selected: Design[]) => void;
}) {
  const [designs, setDesigns] = useState<Design[]>([]);
  const [selectedIds, setSelectedIds] = useState<number[]>([]);

  useEffect(() => {
    async function fetchDesigns() {
      const token = localStorage.getItem("access_token");
      if (!token) {
        alert("Debes iniciar sesión primero.");
        return;
      }

      try {
        const response = await fetch("http://localhost:8000/api/designs/", {
          method: "GET",
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        if (response.ok) {
          const data = await response.json();
          setDesigns(data);
        } else if (response.status === 401) {
          alert("Tu sesión ha expirado. Por favor, inicia sesión nuevamente.");
        } else {
          console.error("Error al cargar diseños:", await response.text());
        }
      } catch (error) {
        console.error("Error al cargar diseños:", error);
      }
    }

    fetchDesigns();
  }, []);

  const toggleSelection = (id: number) => {
    setSelectedIds((prev) => {
      const newSelectedIds = prev.includes(id)
        ? prev.filter((selectedId) => selectedId !== id)
        : [...prev, id];

      const selectedDesigns = designs.filter((design) =>
        newSelectedIds.includes(design.id)
      );

      onSelectionChange(selectedDesigns);
      return newSelectedIds;
    });
  };

  const handleDelete = async (id: number) => {
    const token = localStorage.getItem("access_token");
    if (!token) {
      alert("Debes iniciar sesión primero.");
      return;
    }

    try {
      const response = await fetch(
        `http://localhost:8000/api/designs/${id}/delete/`,
        {
          method: "DELETE",
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (response.ok) {
        alert("Diseño eliminado exitosamente.");
        setDesigns((prev) => prev.filter((design) => design.id !== id));
      } else {
        console.error("Error al eliminar diseño:", await response.text());
        alert("No se pudo eliminar el diseño.");
      }
    } catch (error) {
      console.error("Error al eliminar diseño:", error);
    }
  };

  return (
    <div style={{ display: "flex", gap: "16px", flexWrap: "wrap" }}>
      {designs.map((design) => (
        <Card
          key={design.id}
          style={{
            width: "200px",
            border:
              selectedIds.includes(design.id) ? "2px solid blue" : "none",
          }}
        >
          <CardBody>
            <Image
              src={`http://localhost:8000/${design.imagen}`}
              alt={design.tipo_prenda}
              width="100%"
              height="150px"
              style={{ objectFit: "cover", borderRadius: "8px" }}
            />
          </CardBody>
          <CardFooter style={{ display: "flex", justifyContent: "space-between" }}>
            <Button
              color={selectedIds.includes(design.id) ? "success" : "primary"}
              size="sm"
              onClick={() => toggleSelection(design.id)}
            >
              {selectedIds.includes(design.id) ? "Deseleccionar" : "Seleccionar"}
            </Button>
            <Button
              color="error"
              size="sm"
              onClick={() => handleDelete(design.id)}
            >
              Eliminar
            </Button>
          </CardFooter>
        </Card>
      ))}
    </div>
  );
}
