"use client";
import { TextGenerateEffect } from "../ui/text-generate-effect";

const words = `Donde la moda y la tecnología se encuentran
`;

export function TextGenerateEffectDemo() {
  return <TextGenerateEffect words={words} />;
}
