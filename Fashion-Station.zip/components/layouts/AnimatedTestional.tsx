import { AnimatedTestimonials } from "@/components/ui/animated-testimonials";

export function AnimatedTestimonialsDemo() {
  const testimonials = [
    {
      quote:
        "Excelente plataforma, fácil de usar y perfecta para personalizar diseños. Me encanta que puedo guardar y editar mis creaciones.",
      name: "Robert Chen",
      designation: "Director del MBA",
      src: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?q=80&w=3560&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
    },
    {
      quote:
        "Gran sitio para crear camisetas y pantalones. Ideal para principiantes, aunque le faltan algunas opciones avanzadas.",
      name: "Emily Watson",
      designation: "Directora de Marketing en Zara",
      src: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?q=80&w=3540&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
    },
    {
      quote:
        "Perfecta para mi marca. Puedo organizar y descargar bocetos, lo que me facilita mucho el trabajo.",
      name: "Artur Morgan",
      designation: "Jefe de Ventas en Mango",
      src: "https://images.unsplash.com/photo-1623582854588-d60de57fa33f?q=80&w=3540&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
    },
    {
      quote:
        "Útil para diseños simples, pero algo limitada en detalles. Buena para ideas iniciales.",
      name: "James Kim",
      designation: "Diseñador de Moda en Desigual",
      src: "https://images.unsplash.com/photo-1636041293178-808a6762ab39?q=80&w=3464&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
    },
    {
      quote:
        "Excelente herramienta para diseñar prendas de calidad. El soporte es muy bueno, ¡seguiré usándola!",
      name: "Louis Thompson",
      designation: "Jefe de Diseño en Pull&Bea",
      src: "https://images.unsplash.com/photo-1624561172888-ac93c696e10c?q=80&w=2592&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
    },
  ];
  return <AnimatedTestimonials testimonials={testimonials} />;
}
