import SignupFormDemo from "@/components/example/signup-form-demo";

export default function SignUpForm() {
  return (
    <div>
      <SignupFormDemo />
    </div>
  );
}
