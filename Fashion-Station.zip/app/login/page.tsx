import LogInFormDemo from "@/components/example/login-form";

export default function SignUpForm() {
  return (
    <div>
      <LogInFormDemo />
    </div>
  );
}
