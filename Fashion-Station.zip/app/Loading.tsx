"use client";
import React from "react";
import { Spinner } from "@nextui-org/spinner";

export default function Loading() {
  return <Spinner label="Secondary" color="secondary" labelColor="secondary" />;
}
