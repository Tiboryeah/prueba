import React from "react";
import AppNew from "./AppNew";

export default function page() {
  return (
    <>
      <AppNew />
    </>
  );
}
