"use client";
import React, { useEffect, useRef, useState } from "react";
import * as fabric from "fabric";
import "./Styles.css";
import { handleObjectMoving, clearGuidelines } from "./snappingHelpers";
import Settings from "./settings";
import { IconButton } from "@mui/material";
import ChangeHistoryIcon from '@mui/icons-material/ChangeHistory';
import CropSquareIcon from '@mui/icons-material/CropSquare';
import PanoramaFishEyeIcon from '@mui/icons-material/PanoramaFishEye';
import ImageIcon from '@mui/icons-material/Image';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import ArrowCircleDownIcon from '@mui/icons-material/ArrowCircleDown';
import RemoveIcon from '@mui/icons-material/Remove';
import FormatShapesIcon from '@mui/icons-material/FormatShapes';
import SaveIcon from '@mui/icons-material/Save';

export default function AppNew() {
  const canvasRef = useRef(null);
  const [canvas, setCanvas] = useState(null);
  const fileInputRef = useRef(null);
  const [guidelines, setGuidelines] = useState([]);

  useEffect(() => {
    if (canvasRef.current) {
      const initCanvas = new fabric.Canvas(canvasRef.current, {
        width: window.innerWidth * 0.9,
        height: window.innerHeight,
      });

      initCanvas.backgroundColor = " #eeeeee ";
      initCanvas.renderAll();

      setCanvas(initCanvas);

      initCanvas.on("object:moving", (event) =>
        handleObjectMoving(initCanvas, event.target, guidelines, setGuidelines)
      );

      initCanvas.on("object:modified", () =>
        clearGuidelines(initCanvas, guidelines, setGuidelines)
      );

      const handleKeyPress = (event) => {
        if (event.key === "Delete" || event.key === "Backspace") {
          deleteSelectedObject();
        }
      };

      window.addEventListener("keydown", handleKeyPress);

      const resizeCanvas = () => {
        initCanvas.setWidth(window.innerWidth * 0.8);
        initCanvas.setHeight(window.innerHeight);
        initCanvas.renderAll();
      };

      window.addEventListener("resize", resizeCanvas);

      return () => {
        window.removeEventListener("keydown", handleKeyPress);
        initCanvas.dispose();
        window.removeEventListener("resize", resizeCanvas);
      };
    }
  }, []);

  const addRectangle = () => {
    if (canvas) {
      const rect = new fabric.Rect({
        left: 50,
        top: 100,
        fill: "blue",
        width: 100,
        height: 60,
        id: `rect_${new Date().getTime()}`, // Asignamos un ID único
      });
      canvas.add(rect);
      canvas.renderAll();
    } else {
      console.error("Canvas no está inicializado.");
    }
  };

  const addCircle = () => {
    if (canvas) {
      const circle = new fabric.Circle({
        left: 100,
        top: 100,
        fill: "red",
        radius: 60,
        id: `circle_${new Date().getTime()}`, // Asignamos un ID único
      });
      canvas.add(circle);
      canvas.renderAll();
    } else {
      console.error("Canvas no está inicializado.");
    }
  };

  const addTriangle = () => {
    if (canvas) {
      const triangle = new fabric.Triangle({
        left: 150,
        top: 150,
        fill: "green",
        width: 100,
        height: 100,
        id: `triangle_${new Date().getTime()}`, // Asignamos un ID único
      });
      canvas.add(triangle);
      canvas.renderAll();
    } else {
      console.error("Canvas no está inicializado.");
    }
  };

  const addLine = () => {
    if (canvas) {
      const line = new fabric.Line([50, 100, 200, 100], {
        left: 50,
        top: 100,
        stroke: "orange",
        strokeWidth: 5,
        id: `line_${new Date().getTime()}`, // Asignamos un ID único
      });
      canvas.add(line);
      canvas.renderAll();
    } else {
      console.error("Canvas no está inicializado.");
    }
  };

  const addText = () => {
    if (canvas) {
      const textbox = new fabric.Textbox("¡Hola, Canvas!", {
        left: 200,
        top: 200,
        fontSize: 30,
        fill: "black",
        width: 200,
        editable: true,
        id: `text_${new Date().getTime()}`, // Asignamos un ID único
      });
      canvas.add(textbox);
      canvas.renderAll();
    } else {
      console.error("Canvas no está inicializado.");
    }
  };

  const addImageFromFile = (event) => {
    if (canvas) {
      const file = event.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
          const img = new Image();
          img.src = e.target.result;
          img.onload = () => {
            const fabricImage = new fabric.Image(img, {
              left: 100,
              top: 100,
              scaleX: 1,
              scaleY: 1,
              id: `image_${new Date().getTime()}`, // Asignamos un ID único
            });
            canvas.add(fabricImage);
            canvas.renderAll();
          };
        };
        reader.readAsDataURL(file);
      }
    } else {
      console.error("Canvas no está inicializado.");
    }
  };

  const triggerFileInputClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const deleteSelectedObject = () => {
    if (canvas) {
      const activeObject = canvas.getActiveObject();
      if (activeObject) {
        canvas.remove(activeObject);
        canvas.renderAll();
      } else {
        console.error("No hay objeto seleccionado para eliminar.");
      }
    }
  };

  const downloadCanvas = () => {
    if (canvas) {
      const dataURL = canvas.toDataURL({ format: "png" });
      const link = document.createElement("a");
      link.href = dataURL;
      link.download = "canvas_image.png";
      link.click();
    } else {
      console.error("Canvas no está inicializado.");
    }
  };

// Función para guardar el diseño en el backend
const saveCanva = async () => {
  const token = localStorage.getItem("access_token");
  const refreshToken = localStorage.getItem("refresh_token");

  if (!token || !refreshToken) {
    alert("Debes iniciar sesión primero.");
    return;
  }

  const tipoPrenda = "Playera";

  if (!canvas) {
    console.error("Canvas no definido.");
    alert("No se pudo obtener el diseño del canvas.");
    return;
  }

  const dataUrl = canvas.toDataURL("image/png");

  if (!dataUrl) {
    alert("No se pudo obtener la imagen del canvas.");
    return;
  }

  const data = {
    tipo_prenda: tipoPrenda,
    imagen: dataUrl, // Asegúrate de que esto sea una imagen válida en base64
  };

  try {
    const response = await fetchWithRefresh("http://localhost:8000/api/designs/create/", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    });

    if (response && response.ok) {
      alert("Diseño guardado exitosamente.");
    } else {
      const error = await response.json();
      console.error("Error del backend:", error);
      alert(`Error: ${error.detail || "No se pudo guardar el diseño"}`);
    }
  } catch (error) {
    console.error("Error al guardar diseño:", error);
    alert("Ocurrió un error inesperado.");
  }
};

// Función reutilizable para realizar solicitudes con manejo de refresh tokens
const fetchWithRefresh = async (url, options) => {
  let token = localStorage.getItem("access_token");
  const refreshToken = localStorage.getItem("refresh_token");

  if (!token) {
    alert("Tu sesión ha expirado. Por favor, inicia sesión nuevamente.");
    localStorage.removeItem("access_token");
    localStorage.removeItem("refresh_token");
    return null;
  }

  try {
    // Intenta realizar la solicitud original
    let response = await fetch(url, {
      ...options,
      headers: {
        ...options.headers,
        Authorization: `Bearer ${token}`,
      },
    });

    // Si el token está expirado (401), intenta renovarlo
    if (response.status === 401 && refreshToken) {
      console.log("Token expirado. Intentando refrescar...");

      // Solicitar un nuevo token de acceso con el refresh token
      const refreshResponse = await fetch("http://localhost:8000/api/token/refresh/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ refresh: refreshToken }),
      });

      if (refreshResponse.ok) {
        const newTokens = await refreshResponse.json();
        localStorage.setItem("access_token", newTokens.access);

        // Reintentar la solicitud original con el nuevo token
        response = await fetch(url, {
          ...options,
          headers: {
            ...options.headers,
            Authorization: `Bearer ${newTokens.access}`,
          },
        });
      } else {
        console.error("El refresh token ya no es válido.");
        alert("Tu sesión ha expirado. Por favor, inicia sesión nuevamente.");
        localStorage.removeItem("access_token");
        localStorage.removeItem("refresh_token");
        return null;
      }
    }

    return response;
  } catch (error) {
    console.error("Error en la solicitud:", error);
    alert("Ocurrió un error al procesar la solicitud.");
    return null;
  }
};

  
  
  return (
    <div className="AppNew">
      <div className="Toolbar darkmode">
        <IconButton onClick={addRectangle}>
          <CropSquareIcon style={{ fontSize: 30 }} />
        </IconButton>
        <IconButton onClick={addCircle}>
          <PanoramaFishEyeIcon style={{ fontSize: 30 }} />
        </IconButton>
        <IconButton onClick={addTriangle}>
          <ChangeHistoryIcon style={{ fontSize: 30 }} />
        </IconButton>
        <IconButton onClick={addLine}>
          <RemoveIcon style={{ fontSize: 30 }} />
        </IconButton>
        <IconButton onClick={addText}>
          <FormatShapesIcon style={{ fontSize: 30 }} />
        </IconButton>
        <IconButton onClick={deleteSelectedObject}>
          <DeleteOutlineIcon style={{ fontSize: 30 }} />
        </IconButton>
        <IconButton onClick={triggerFileInputClick}>
          <ImageIcon style={{ fontSize: 30 }} />
        </IconButton>
        <IconButton onClick={downloadCanvas}>
          <ArrowCircleDownIcon style={{ fontSize: 30 }} />
        </IconButton>
        <IconButton onClick={saveCanva}>
          <SaveIcon style={{ fontSize: 30 }} />
        </IconButton>
        <input
          ref={fileInputRef}
          type="file"
          style={{ display: "none" }}
          accept="image/*"
          onChange={addImageFromFile}
        />
      </div>

      <div className="canvasContainer">
        <canvas ref={canvasRef} />
        <Settings canvas={canvas} />
      </div>
    </div>
  );
}