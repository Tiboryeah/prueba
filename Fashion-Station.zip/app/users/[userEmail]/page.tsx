"use client";
import React, { useState, useEffect } from "react";
import { AlertDialogDemo } from "@/components/layouts/NuevaPrenda";
import { Button } from "@nextui-org/button";
import CardDemo from "@/components/layouts/CardDemo";

export default function UserPage({ params }: any) {
  const [email, setEmail] = useState<string | null>(null);
  const [selectedDesigns, setSelectedDesigns] = useState<any[]>([]);

  useEffect(() => {
    (async () => {
      const resolvedParams = await params;
      setEmail(decodeURIComponent(resolvedParams.userEmail));
    })();
  }, [params]);

  const handleExport = async () => {
    if (selectedDesigns.length === 0) {
      alert("No se han seleccionado diseños para exportar.");
      return;
    }

    try {
      selectedDesigns.forEach(async (design) => {
        const response = await fetch(`http://localhost:8000/${design.imagen}`);
        if (response.ok) {
          const blob = await response.blob();
          const link = document.createElement("a");
          link.href = URL.createObjectURL(blob);
          link.download = design.imagen.split("/").pop(); // Nombre del archivo
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
        } else {
          console.error("Error al descargar el diseño:", response.statusText);
        }
      });

      alert("Diseños exportados exitosamente.");
    } catch (error) {
      console.error("Error al exportar diseños:", error);
      alert("Ocurrió un error al exportar los diseños.");
    }
  };

  if (!email) {
    return <div>Loading...</div>;
  }

  return (
    <>
      <h1 className="scroll-m-20 text-4xl font-extrabold tracking-tight lg:text-5xl">
        Bienvenido {email}
      </h1>
      <p className="my-5 text-lg">¿Qué quisieras hacer ahora?</p>
      <div className="flex flex-wrap gap-4 items-center">
        <AlertDialogDemo email={email} />
        <Button color="warning" variant="flat" onClick={handleExport}>
          Exportar y compartir
        </Button>
      </div>
      <p className="my-5">Diseños recientemente vistos</p>
      <CardDemo
        email={email}
        onSelectionChange={(selected) => setSelectedDesigns(selected)}
      />
    </>
  );
}
