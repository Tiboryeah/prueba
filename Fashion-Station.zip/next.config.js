export const images = {
  domains: [
    "images.unsplash.com",
    "assets.aceternity.com",
    "img.freepik.com",
    "images.pexels.com",
  ],
};
