"use client";

import React, { createContext, useContext, useEffect, useState, useCallback } from "react";
import { useRouter } from "next/navigation";

interface AuthContextType {
  isAuthenticated: boolean;
  userEmail: string | null;
  login: (token: string, email: string) => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType>({
  isAuthenticated: false,
  userEmail: null,
  login: () => {},
  logout: () => {},
});

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const router = useRouter();

  const syncAuthState = useCallback(() => {
    const token = localStorage.getItem("authToken");
    const email = localStorage.getItem("userEmail");
    setIsAuthenticated(!!token);
    setUserEmail(email || null);
  }, []);

  useEffect(() => {
    syncAuthState();

    const handleAuthChange = () => syncAuthState();
    window.addEventListener("authChange", handleAuthChange);

    return () => {
      window.removeEventListener("authChange", handleAuthChange);
    };
  }, [syncAuthState]);

  const login = useCallback((token: string, email: string) => {
    localStorage.setItem("authToken", token);
    localStorage.setItem("userEmail", email);
    window.dispatchEvent(new Event("authChange"));
    setIsAuthenticated(true);
    setUserEmail(email);
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem("authToken");
    localStorage.removeItem("userEmail");
    window.dispatchEvent(new Event("authChange"));
    setIsAuthenticated(false);
    setUserEmail(null);
    router.push("/");
  }, [router]);

  return (
    <AuthContext.Provider value={{ isAuthenticated, userEmail, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
